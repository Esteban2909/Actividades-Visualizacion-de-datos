#!/usr/bin/env python
# coding: utf-8

# In[1]:


import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import pandas as pd
import numpy as np
import plotly.express as px
import seaborn as sns
import requests


# In[14]:


external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)


# In[2]:


df = pd.read_csv('delitos_sex.csv',
                         encoding='latin-1',
                         sep = ';', decimal=','              
                        )


# In[8]:


df_delitos1 = pd.read_csv('delitos_2020.csv',
                         encoding='latin-1',
                         sep = ';', decimal=',',
                              dtype={
                     'CODIGO DANE UNIFICADO': str
                 }
                        )


# In[5]:


df_delitos = pd.read_csv('delitos_2020.csv',
                         encoding='latin-1',
                         sep = ';', decimal=',',
                              dtype={
                     'CODIGO DANE UNIFICADO': str
                 }
                        )


# In[6]:


## # Analísis de completitud:
## Se revisaron los valores y el porcentaje de datos faltantes para cada variable. Se puede observar que hay valores
#faltantes para las variables "ARMAS MEDIOS", "GENERO" y "AGRUPA EDAD PERSONA".

print('delitos')
print('Filas: ', df_delitos.shape[0])
print('Columnas: ', df_delitos.shape[1])
for col in df_delitos.columns:
    num_missing = df_delitos[col].isnull().sum()
    pct_missing = np.mean(df_delitos[col].isnull())
    #print(col," - ",round(pct_missing*100, 2),"% - ",num_missing)
    print('{} - {}% - {}'.format(col,round(pct_missing*100, 4),num_missing))
    
    df_delitos1["GENERO"]=df_delitos1["GENERO"].replace(np.nan, "NO APLICA")
df_delitos["ARMAS MEDIOS"]=df_delitos["ARMAS MEDIOS"].replace(np.nan, "NO REPORTADO")
df_delitos["AGRUPA EDAD PERSONA"]=df_delitos["AGRUPA EDAD PERSONA"].replace(np.nan, "NO APLICA")
df_delitos1=df_delitos
#Para la variable "Genero" se reemplazaron los valores faltantes por "NO APLICA”, a la variable "ARMAS MEDIOS" 
#los valores faltantes se sustituyeron por la categoría "NO REPORTADO" y Para la variable "AGRUPA EDAD PERSONA" 
#los valores faltantes se sustituyeron por la categoría "NO APLICA".

df_dedupped_delitos = df_delitos.drop_duplicates()
print(df_delitos.shape)
print(df_dedupped_delitos.shape)
print('Cantidad de duplicados',df_delitos.shape[0]-df_dedupped_delitos.shape[0])

## Por la naturaleza de los datos no se eliminaron los duplicados ya que hacen referencia a registros.


# In[12]:



df_sex = df_delitos1[(df_delitos1['DELITO'] == 'DELITOS SEXUALES')]
fil_dep = df_sex["DEPARTAMENTO"].unique()


# In[13]:


df_mot = pd.read_csv('delitos_mot.csv',
                         encoding='latin-1',
                         sep = ';', decimal=','              
                        )


# In[8]:


df11 = df_delitos[df_delitos["AGRUPA EDAD PERSONA"] != "NO APLICA"]

df11 = (df_delitos.groupby(["DELITO", "AGRUPA EDAD PERSONA"])["CANTIDAD"].sum()
        .groupby(level=0)
        .apply(lambda x:round( x / x.sum()*100,2))
        .reset_index(name='DELITOS PORCENTAJE'))

df111=df11.drop([3,7,8],axis=0)
df111 = df11[df11["AGRUPA EDAD PERSONA"] != "NO APLICA"]

fil_del = df111["DELITO"].unique()


df_delitos["DELITO"].value_counts()
df_delitos["ARMAS MEDIOS"].value_counts()

tab1 = pd.crosstab(df_delitos["ARMAS MEDIOS"],df_delitos["DELITO"])
tab1
#df_sex = df_delitos[(df_delitos['DELITO'] == 'DELITOS SEXUALES')]
fil_DEL = df_delitos["DELITO"].unique()

#import plotly.express as px
#ax = sns.heatmap(tab1,cmap="PuRd")


fig5 = px.imshow(tab1,
                labels=dict(x="", y="", color="PuRd"),
               
               )
fig5.update_xaxes(side="top")

fig5.update_layout(
    title_text = 'Mapa de calor',
    font=dict(
        #family="Courier New, monospace",
        #family="Ubuntu",
        size=8.5,
        color="#7f7f7f"
    ),
    annotations = [dict(
        x=0.55,
        y=-0.1,
        xref='paper',
        yref='paper',
        #text='Fuente: <a href=" https://www.policia.gov.co/revistacriminalidad">\
           #Policia.gov </a>',
        showarrow = False
    )]
)


# In[3]:


repo_url = 'https://gist.githubusercontent.com/john-guerra/43c7656821069d00dcbc/raw/be6a6e239cd5b5b803c6e7c2ec405b793a9064dd/Colombia.geo.json' 
col_regions_geo = requests.get(repo_url).json()


# In[16]:


fig3 = px.choropleth(data_frame=df_mot, 
                    geojson=col_regions_geo, 
                    locations='Departamento', # nombre de la columna del Dataframe
                    featureidkey='properties.NOMBRE_DPT',  # ruta al campo del archivo GeoJSON con el que se hará la relación (nombre de los estados)
                    color='Hurto motocicletas', #El color depende de las cantidades
                    color_continuous_scale="greens", #greens
                    #scope="north america"
                   )
fig3.update_geos(showcountries=True, showcoastlines=True, showland=True, fitbounds="locations")

fig3.update_layout(
    title_text = 'Hurto de motocicletas en Colombia',
    font=dict(
        #family="Courier New, monospace",
        family="Ubuntu",
        size=18,
        color="#7f7f7f"
    ),
    annotations = [dict(
        x=0.55,
        y=-0.1,
        xref='paper',
        yref='paper',
        text='Fuente: <a href=" https://www.policia.gov.co/revistacriminalidad">\
           Policia.gov </a>',
        showarrow = False
    )]
)


# In[4]:


fig = px.choropleth(data_frame=df, 
                    geojson=col_regions_geo, 
                    locations='Departamento', # nombre de la columna del Dataframe
                    featureidkey='properties.NOMBRE_DPT',  # ruta al campo del archivo GeoJSON con el que se hará la relación (nombre de los estados)
                    color='Delitos sexuales', #El color depende de las cantidades
                    color_continuous_scale="burg", #greens
                    #scope="north america"
                   )
fig.update_geos(showcountries=True, showcoastlines=True, showland=True, fitbounds="locations")

fig.update_layout(
    title_text = 'Casos de delitos sexuales en Colombia',
    font=dict(
        #family="Courier New, monospace",
        family="Ubuntu",
        size=18,
        color="#7f7f7f"
    ),
    annotations = [dict(
        x=0.55,
        y=-0.1,
        xref='paper',
        yref='paper',
        text='Fuente: <a href=" https://www.policia.gov.co/revistacriminalidad">\
           Policia.gov </a>',
        showarrow = False
    )]
)


# In[ ]:



app.layout = html.Div(
  children=[
      html.H1(children="DELITOS EN COLOMBIA - AÑO 2020",
          style = {
                      'textAlign': 'center',
          }),
      html.H2(children="Contextualización"),
      html.P(
          children="En ésta pagina Web se mostraran visualizaciones "
          "sobre los delitos ocurridos en Colombia para el año 2020. "
          "Se cuenta con variables como delito, genero, grupo de edad "
          "departamento o el tipo de arma utilizada, los datos fueron extraidos de la pagina oficicial de la policia nacional de Colombia.Información extraída del Sistema de Información Estadístico, Delincuencial Contravencional y Operativo de la Policía Nacional – SIEDCO. Cifras sujetas a variación, en proceso de unificación con otros organismos del Estado..."
          ),   

 html.Div([
     html.Div([
         html.H1(children='Mapa coroplético - Delitos sexuales en Colombia (Año 2020)'),#
          html.Div(children='''
            Esta visualización muestra la cantidad de delitos sexuales por departamento en Colombia para el año 2020 (Elaborado por Daniel Gómez)
        '''),#
         dcc.Graph(
              id='example-graph-1',
              figure=fig
          ),  
      ], className='six columns'),

### Viz 2 ###
      html.Div([
          html.H1(children='Delitos sexuales por departamento, genero y cantidad'),#
          html.Div(children='''
              Esta visualización muestra el comportamiento de los delitos sexuales por departamento y genero. Cuenta con un crossfilter para poder hacer comparaciones entre departamentos eficazmente(Elaborado por Daniel Gómez)
          '''),#
          dcc.Checklist(id='crossfilter_departamento',
              options=[{'label': i, 'value': i} 
                          for i in fil_dep],
              value = ['BOGOTÁ.D.C','ANTIOQUIA'],
              labelStyle={'display': 'inline-block'}
              ),
          dcc.Graph(
              id='example-graph-2'
          ),  
      ], className='six columns'),
     ], className='row'),#
      
      html.Div([
     html.Div([
         html.H1(children='Mapa coroplético - Hurto de motocicletas en Colombia '),#
          html.Div(children='''
            Este mapa muestra la cantidad de hurtos de motocicletas en Colombia en el año 2020(Elaborado por Sergio Blanco)
        '''),#
         dcc.Graph(
              id='example-graph-3',
              figure=fig3
          ),  
      ], className='six columns'),
          html.Div([
          html.H1(children='Delitos por tipo de delito, edad y porcentaje'),#
          html.Div(children='''
              De acuerdo con el gráfico de barras siguiente, muestra los delitos por agrupación de edad; personas adultas, adolescentes y menores agregados por homicidios, violencia sexual y violencia intrafamiliar para el año 2020(Elaborado por Sergio Blanco)
          '''),#
          dcc.Checklist(id='crossfilter_delitos',
              options=[{'label': i, 'value': i} 
                          for i in fil_del],
              value = ['DELITOS SEXUALES','HOMICIDIOS'],
              labelStyle={'display': 'inline-block'}
              ),
          dcc.Graph(
              id='example-graph-4'
          ),  
      ], className='six columns'),
     ], className='row'),#
       html.Div([
     html.Div([
         html.H1(children='Mapa de calor-Tipo de delito y  arma - 2020'),#
          html.Div(children='''
            Este gráfico de calor representa la relación que tiene el tipo de delito con el arma empleada en el hecho(Elaborado por Karen Fonseca) 
        '''),#
         dcc.Graph(
              id='example-graph-5',
              figure=fig5
          ),  
      ], className='six columns'),


### Viz 2 ###
      html.Div([
          html.H1(children='Gráfico de barras - Tipo de delitos por departamento'),#
          html.Div(children='''
              Está visualización permite identificar el número de casos para cada tipo delito por departamento en el año 2020(Elaborado por Karen Fonseca)
          '''),#
          dcc.Checklist(id='crossfilter_DELITO',
              options=[{'label': i, 'value': i} 
                          for i in fil_DEL],
              value = ['VIOLENCIA INTRAFAMILIAR','DELITOS SEXUALES '],
            
              labelStyle={'display': 'inline-block'}
              ),
          dcc.Graph(
              id='example-graph-6'
          ),  
      ], className='six columns'),
     ], className='row'),#
           
               

])

@app.callback(
  dash.dependencies.Output('example-graph-2', 'figure'),
  [dash.dependencies.Input('crossfilter_departamento', 'value')]
  )
def update_graph(DEPARTAMENTO_value):

  query1 = df_sex[df_sex['DEPARTAMENTO'].isin(DEPARTAMENTO_value)]
  query1 = pd.pivot_table(query1, 
                      values='CANTIDAD', 
                      index=['DEPARTAMENTO','GENERO'],
                      aggfunc=np.sum)
  query1 = query1.reset_index().rename_axis(None, axis=1)
  query1 = query1.sort_values(by=['CANTIDAD'],ascending=False)

  fig2 = px.bar(query1, x='CANTIDAD', y='DEPARTAMENTO', color = 'GENERO')

  return fig2

@app.callback(
  dash.dependencies.Output('example-graph-4', 'figure'),
  [dash.dependencies.Input('crossfilter_delitos', 'value')]
  )
def update_graph(delito_value):

  query2 = df111[df111['DELITO'].isin(delito_value)]
  query2 = pd.pivot_table(query2, 
                      values='DELITOS PORCENTAJE', 
                      index=['DELITO','AGRUPA EDAD PERSONA'],
                      aggfunc=np.sum)
  query2 = query2.reset_index().rename_axis(None, axis=1)
  query2 = query2.sort_values(by=['DELITOS PORCENTAJE'],ascending=False)

  fig4 = px.bar(query2, x='DELITOS PORCENTAJE', y='DELITO', color = 'AGRUPA EDAD PERSONA')

  return fig4

@app.callback(
  dash.dependencies.Output('example-graph-6', 'figure'),
  [dash.dependencies.Input('crossfilter_DELITO', 'value')]
  )
def update_graph(DELITO_value):

  query3 = df_delitos[df_delitos['DELITO'].isin(DELITO_value)]
  query3 = pd.pivot_table(query3, 
                      values='CANTIDAD', 
                      index=['DELITO','DEPARTAMENTO'],
                      aggfunc=np.sum)
  query3 = query3.reset_index().rename_axis(None, axis=1)
  query3 = query3.sort_values(by=['CANTIDAD'],ascending=False)

  fig6 = px.bar(query3, x='CANTIDAD', y='DEPARTAMENTO', color = 'DELITO')

  return fig6




if __name__ == "__main__":
  app.run_server(debug=True)

